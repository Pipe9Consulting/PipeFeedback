﻿Requires Open XML SDK (version 2.0 is included in Libraries folder)

This is an in-progress lib for generating Excel documents in memory from source data, with most
focus given to DataTable as input for now. Can also use existing Excel document as a template
to provide cell styling for colums, etc.

250,000 rows, 10-20 columns is pushing the limits for the current implementation (time and memory usage)

See Documents folder in TFS for more info.